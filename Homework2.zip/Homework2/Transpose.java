import org.apache.commons.lang.StringUtils;
import org.apache.hadoop.fs.Path;
import org.apache.hadoop.conf.*;
import org.apache.hadoop.io.*;
import org.apache.hadoop.mapreduce.*;
import org.apache.hadoop.mapreduce.lib.input.FileInputFormat;
import org.apache.hadoop.mapreduce.lib.input.TextInputFormat;
import org.apache.hadoop.mapreduce.lib.output.FileOutputFormat;
import org.apache.hadoop.mapreduce.lib.output.TextOutputFormat;

import java.io.IOException;
import java.util.*;

public class Transpose {

    public static class Map extends Mapper<LongWritable, Text, LongWritable, Text> {

        public void map(LongWritable key, Text value, Context context) throws IOException, InterruptedException {
            long col_index = 0; // initialize the value of the column to 0
            long row_index = key.get(); // the value of the row is given by the key put in map's arguments

            String[] row_value = value.toString().split(","); // split the value of the row to get its elements
            for (String elem : row_value ) {
                context.write(new LongWritable(col_index), new Text(row_index + "," + elem));
                col_index++;
            }
        }
    }

    public static class Reduce extends Reducer<LongWritable, Text, Text, NullWritable> {

        public void reduce(LongWritable key, Iterable<Text> values, Context context) throws IOException, InterruptedException {

            HashMap<Long, String> new_row = new HashMap<>(); // HashMap structure to store (key,value) pairs of the row and its value
            for (Text val : values) {
                String[]  str = val.toString().split(","); // retrieve the tuple (old_row_index, value)
                new_row.put(Long.valueOf(str[0]), str[1]); // put them in the HashMap
            }
            String elem_row = StringUtils.join(new_row.values(), ',');// put a comma separator between the values
            context.write(new Text(elem_row), NullWritable.get());


        }
    }
    public static void main(String[] args) throws Exception {
        Configuration conf = new Configuration();
        Job job = Job.getInstance(conf, "transpose");
        job.setJarByClass(Transpose.class);
        job.setOutputKeyClass(LongWritable.class);
        job.setOutputValueClass(MapWritable.class);
        job.setMapperClass(Map.class);
        job.setReducerClass(Reduce.class);
        job.setInputFormatClass(TextInputFormat.class);
        job.setOutputFormatClass(TextOutputFormat.class);
        FileInputFormat.addInputPath(job, new Path(args[0]));
        FileOutputFormat.setOutputPath(job, new Path(args[1]));
        job.waitForCompletion(true);
    }

}